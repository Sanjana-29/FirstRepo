package breport.page.actions;

import breport.config.CommonActions;

public class ReportsActions extends CommonActions {

	public static void goToReports() {
		click(breport.objects.NavigationObjects.reports_menu);
	}
	
	public static void reportsUrl() {
		verifyUrl("https://webbgm.bauer.de/testbreport/resources/dashboard.html#report");
	}
	
	
}
