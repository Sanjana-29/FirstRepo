package breport.page.actions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;

import breport.config.CommonActions;
import junit.framework.Assert;

public class UploadActions extends CommonActions {

	public static void uploadFileWithRobot(String string) throws AWTException, InterruptedException {
		//StringSelection is a class that can be used for copy and paste operations.
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		Robot robot = new Robot();

		robot.keyPress(KeyEvent.VK_CONTROL);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_V);
		Thread.sleep(2000);  
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(2000);  
		
	}

	public static void uploadFile() throws InterruptedException, AWTException {
		click(breport.objects.NavigationObjects.upload_menu);
		Thread.sleep(2000);
		verifyTexts(breport.objects.UploadObjects.upload_title,"Upload Files", "Title is present");
		verifyElement(breport.objects.UploadObjects.upload_addFiles, "Add files button is present");
		verifyElement(breport.objects.UploadObjects.upload_startUpload, "Start upload button is present");
		verifyElement(breport.objects.UploadObjects.upload_delete, "Delete button is present");
		
//		click(breport.objects.UploadObjects.upload_addFiles);
//		switchTab(1);
//		breport.objects.UploadObjects.upload_addFiles.sendKeys("D:\\Data\\Downloads\\TestFileUpload");
		
		click(breport.objects.UploadObjects.upload_addFiles);
		uploadFileWithRobot("D:\\Data\\Downloads\\TestFileUpload");
		
		verifyTexts(breport.objects.UploadObjects.upload_fileName, "TestFileUpload.dat", "Uploade filename verified");
		verifyElement(breport.objects.UploadObjects.upload_startButton, "Start button is present");
		verifyElement(breport.objects.UploadObjects.upload_cancelButton, "Cancel button is present");
		verifyElement(breport.objects.UploadObjects.upload_close_cancelButton, "Close/Cancel button is present");

		click(breport.objects.UploadObjects.upload_startButton);
		Thread.sleep(3000);
		verifyElement(breport.objects.UploadObjects.upload_success, "Success lable is present");
//		verifyTexts(breport.objects.UploadObjects.upload_success_message, "Success File Uploaded Successfully", "Success message verified");
//		click(breport.objects.UploadObjects.upload_close_cancelButton);
		
	}

	public static void uploadFile_duplicate() throws InterruptedException, AWTException {
		click(breport.objects.UploadObjects.upload_addFiles);
		uploadFileWithRobot("D:\\Data\\Downloads\\TestFileUpload");
		Thread.sleep(3000);
		click(breport.objects.UploadObjects.upload_startButton);
		verifyElement(breport.objects.UploadObjects.upload_error, "Failure lable present");
//		verifyTexts(breport.objects.UploadObjects.upload_failure_message, "File Exists On Server", "Failure message verified");
		verifyElement(breport.objects.UploadObjects.upload_failure_cancelButton, "Cancel button is present");
		click(breport.objects.UploadObjects.upload_close_cancelButton);
		
		Assert.assertEquals(driver.findElement(By.xpath("//table[@id='file-records']/tbody/tr[1]/td[1]")).getText(), "TestFileUpload.dat");
	}
}
