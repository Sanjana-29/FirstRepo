package breport.page.actions;

import breport.config.CommonActions;
import breport.objects.*;


public class LoginActions extends CommonActions{

	public static void username() {
		click(breport.objects.LoginObjects.uname);
		sendKeys(breport.objects.LoginObjects.uname, "priyanka.bhale@bauer.de");
	}
	
	public static void password() {
		click(breport.objects.LoginObjects.password);
		sendKeys(breport.objects.LoginObjects.password, "6evFuxUl");
	}
	
	public static void submit() throws InterruptedException {
		click(breport.objects.LoginObjects.login);
		Thread.sleep(10000);
	}
	
	public static void pagetitle() {
		verifyPageTitle("WEB-BGM Dashboard", "Page title on Dashboard page is passed", "page title did not match");
	}
	
	public static void homepage() {
		verifyTexts(breport.objects.LoginObjects.pageheader, "Bauer WEB-BGM", "Header- 'Bauer WEB-BGM' is present");
	}
}
