package breport.page.actions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.ClickAction;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;

import Flash.FlashObjectWebDriver;
import breport.config.CommonActions;

public class RecordsActions extends CommonActions {

	public static void brecords() throws InterruptedException {
		click(breport.objects.RecordsObjects.breports_tab);
		Thread.sleep(10000);
	}

	public static void pageTitle() {
		switchTab(1);
		verifyPageTitle("B-Reportt", "Title test passed", "Title test failed");
	}

	public static void url() {
		verifyUrl("https://webbgm.bauer.de/testbreport/resources/dashboard.html#/records");
	}

	public static void navigation() {
		verifyElement(breport.objects.NavigationObjects.record_menu, "Record menu is present");
		verifyElement(breport.objects.NavigationObjects.reports_menu, "Reports menu is present");
		verifyElement(breport.objects.NavigationObjects.dailyreport_menu, "Daily Reports menu is present");
		verifyElement(breport.objects.NavigationObjects.upload_menu, "Upload menu is present");
		verifyElement(breport.objects.NavigationObjects.offline_menu, "Work offline menu is present");
		verifyElement(breport.objects.NavigationObjects.help_menu, "Help menu is present");
		verifyElement(breport.objects.NavigationObjects.language_menu, "Language dropdown is present");
		verifyElement(breport.objects.NavigationObjects.applicationType_menu, "User Application type menu is present");
		verifyElement(breport.objects.NavigationObjects.close_button, "Close button is present");
	}

	public static void logo() {
		verifyElement(breport.objects.RecordsObjects.logo, "B-Report logo is displayed");
	}

	public static void header() {
		verifyTexts(breport.objects.RecordsObjects.header, "File Records", "Header- 'File Records' is present");
	}

	public static void footer() {
		verifyTexts(breport.objects.RecordsObjects.footer, "Copyright � 2014-2019 by BAUER Maschinen GmbH. All rights reserved.", "Verified Footer panel");
	}

	public static void selectMachine() throws InterruptedException {
		//Verify lables of drop-down list/Date picker

		verifyTexts(breport.objects.RecordsObjects.sm_lable, "Select Machine:", "Lable- 'Select Machine' is present");
		verifyTexts(breport.objects.RecordsObjects.startDateCalander_lable, "Begin Date:","Lable- 'Begin Date' is present");
		verifyTexts(breport.objects.RecordsObjects.endDateCalander_lable,"End Date:", "Lable- 'End Date' is present");

		//Select Machine
		moveToElement(breport.objects.RecordsObjects.sm_dropdown);
		click(breport.objects.RecordsObjects.sm_dropdown);
		Thread.sleep(5000);
		breport.objects.RecordsObjects.sm_dropdown_searchbox.sendKeys("01K00234567 - BG30-V - 8002");
		breport.objects.RecordsObjects.sm_dropdown_searchbox.sendKeys(Keys.ENTER);
		Thread.sleep(5000);


		//		Point loc = breport.objects.RecordsObjects.sm_dropdown.getLocation();
		//		WebElement	element_to_click = driver.execute_script("return document.elementFromPoint(arguments[0], arguments[1]);", loc[250], loc[90]);
		//		element_to_click.click();

		//		JavascriptExecutor executor = (JavascriptExecutor)driver;
		//		executor.executeScript("arguments[0].click()",breport.objects.RecordsObjects.sm_dropdown);

		//		WebDriverWait wait2 = new WebDriverWait(driver, 10);
		//		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='select2-selection__arrow']")));
	}

	public static void selectInvalidDate() throws InterruptedException {
		//Select start date
		click(breport.objects.RecordsObjects.startDateCalander);

		dropdown(breport.objects.RecordsObjects.sm_month, "text", "Jun", 0);

		dropdown(breport.objects.RecordsObjects.sm_year, "text", "2019", 0);

		datePicker(breport.objects.RecordsObjects.datePicker, "1");
		Thread.sleep(3000);

		//Select end date
		click(breport.objects.RecordsObjects.endDateCalander);

		dropdown(breport.objects.RecordsObjects.sm_month, "text", "Jan", 0);

		dropdown(breport.objects.RecordsObjects.sm_year, "text", "2019", 0);

		datePicker(breport.objects.RecordsObjects.datePicker, "1");

		click(breport.objects.RecordsObjects.getFiles_button);
		Thread.sleep(3000);
		verifyTexts(breport.objects.RecordsObjects.file_record_info, "Showing 0 to 0 of 0 entries", "No file records found");
		Assert.assertEquals(breport.objects.RecordsObjects.row_odd.getText(), "No data available in table");
	}

	public static void selectValidDate() throws InterruptedException {
		//Select start date
		click(breport.objects.RecordsObjects.startDateCalander);

		dropdown(breport.objects.RecordsObjects.sm_month, "text", "Jan", 0);

		dropdown(breport.objects.RecordsObjects.sm_year, "text", "2019", 0);

		datePicker(breport.objects.RecordsObjects.datePicker, "1");
		Thread.sleep(3000);

		//Select end date
		click(breport.objects.RecordsObjects.endDateCalander);

		dropdown(breport.objects.RecordsObjects.sm_month, "text", "Jun", 0);

		dropdown(breport.objects.RecordsObjects.sm_year, "text", "2019", 0);

		datePicker(breport.objects.RecordsObjects.datePicker, "1");

		click(breport.objects.RecordsObjects.getFiles_button);
		Thread.sleep(5000);
		verifyTexts(breport.objects.RecordsObjects.file_record_info, "Showing 1 to 10 of 182 entries", "182 file records found");
		//Assert.assertEquals(breport.objects.RecordsObjects.row1.getText(), "No data available in table");	
	}

	public static void toggleColumns () throws InterruptedException {

		List<WebElement> button1 = breport.objects.RecordsObjects.toggleColumn.findElements(By.tagName("a"));
		String expected = "#3276b1";
		for(int i=0; i<button1.size(); i++){
			moveToElement(button1.get(i));
			//System.out.println(button1.get(i).getText());
			String color = button1.get(i).getCssValue("background-color");
			String hex = Color.fromString(color).asHex();
			Assert.assertEquals(expected, hex);
			Thread.sleep(2000);
			verifyElement(button1.get(i), button1.get(i).getText() +" is present");
		}
		System.out.println("Hover color verified");
	}

	public static void enableAllColumns() throws InterruptedException {			
		click(breport.objects.RecordsObjects.dataLength);
		click(breport.objects.RecordsObjects.client);
		click(breport.objects.RecordsObjects.machine);
		Thread.sleep(3000);

		List<WebElement> rowval = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));			
		List<WebElement> colHeader = rowval.get(0).findElements(By.tagName("th"));

		List<WebElement> button = breport.objects.RecordsObjects.toggleColumn.findElements(By.tagName("a"));
		if(colHeader.size()==9) {
			for(int i=0; i<colHeader.size(); i++){

				String colName = colHeader.get(i).getText();

				switch(colName) {

				case "File Name":

					verifyElement(breport.objects.RecordsObjects.colFilename, "File name column is present");

					break;

				case "Pile no":

					verifyElement(breport.objects.RecordsObjects.colPileno, "Pileno column is present");

					break;

				case "Start Date Time":

					verifyElement(breport.objects.RecordsObjects.colStartDateTime, "Start Date Time column is present");

					break;

				case "Jobsite":

					verifyElement(breport.objects.RecordsObjects.colJobsite, "Jobsite column is present");

					break;

				case "Operator":

					verifyElement(breport.objects.RecordsObjects.colOperator, "Operator column is present");

					break;

				case "Data Length":

					verifyElement(breport.objects.RecordsObjects.colDatalength, "Data Length column is  present");

					break;

				case "Client":

					verifyElement(breport.objects.RecordsObjects.colClient, "Client column is  present");

					break;

				case "Machine":

					verifyElement(breport.objects.RecordsObjects.colMachine, "Machine column is  present");

					break;

				case "Action":

					verifyElement(breport.objects.RecordsObjects.colAction, "Action column is  present");

					break;
				}
			}
		}else {
			System.out.println("Error in adding columns");
			Assert.assertFalse(true);
		}
	}

	public static void disableColumns() throws InterruptedException {	
		List<WebElement> button2 = breport.objects.RecordsObjects.toggleColumn.findElements(By.tagName("a"));
		for(int i=0; i<button2.size(); i++) {
			button2.get(i).click();
		}
		Thread.sleep(2000);
		List<WebElement> rowval = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));			
		List<WebElement> colHeader = rowval.get(0).findElements(By.tagName("th"));
		if(colHeader.size()==2) {
			Assert.assertEquals(colHeader.get(0).getText(), "File Name");
			Assert.assertEquals(colHeader.get(1).getText(), "Action");
			test.log(LogStatus.PASS, "Remove columns test passed");
		}
		else {
			System.out.println("More than 2 columns are displayed");
			Assert.assertFalse(true);
			test.log(LogStatus.FAIL, "Remove columns test failed");
		}
	}

	public static void columnFilters() {
		List<WebElement> colFilter = breport.objects.RecordsObjects.columnFilters.findElements(By.tagName("select"));
		System.out.println(colFilter.size());

		for(int i=0; i<colFilter.size(); i++) {	
			Select file = new Select(colFilter.get(i));
			file.getFirstSelectedOption();
			String filename = file.getFirstSelectedOption().getText();
			verifyElement(colFilter.get(i), filename);

			click(colFilter.get(i));
			List<WebElement> itemsInDropdown = colFilter.get(i).findElements(By.tagName("option"));
			int size = itemsInDropdown.size();
			int randmNumber = ThreadLocalRandom.current().nextInt(0, size);
			itemsInDropdown.get(randmNumber).click();
			//		Thread.sleep(2000);
		}
	}

	public static void saveFile() throws InterruptedException {

		click(breport.objects.RecordsObjects.saveButton);
		click(breport.objects.RecordsObjects.excelButton);

		Thread.sleep(3000);
		click(breport.objects.RecordsObjects.saveButton);
		click(breport.objects.RecordsObjects.excelButton);
	}

	public static void selectAll() throws InterruptedException {
		click(breport.objects.RecordsObjects.selectallButton);
		Thread.sleep(5000);
		List<WebElement> rowvalue = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));	

		for (int i=1; i<rowvalue.size(); i++) {						
			boolean all = rowvalue.get(i).isSelected();
			System.out.println(rowvalue.get(i).getText() +" is selected");
			Assert.assertTrue("is selected", true);
		}
		System.out.println("All rows are selected");
	}

	public static void selectNone() throws InterruptedException {
		isbuttonEnabled(breport.objects.RecordsObjects.selectnoneButton, "/'Select none'/ button is enabled");

		click(breport.objects.RecordsObjects.selectnoneButton);
		Thread.sleep(8000);

		List<WebElement> rowvalue1 = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));	

		for (int i=1; i<rowvalue1.size(); i++) {						
			boolean none = rowvalue1.get(i).isSelected();

			if(none==false) {
				System.out.println(rowvalue1.get(i).getText() +" is not selected");
			}
			else {
				System.out.println(rowvalue1.get(i).getText() +" is selected");
			}
			Assert.assertFalse(none);
		}
		System.out.println("No rows are selected");
	}

	public static void actionIcons() throws InterruptedException {

		List<WebElement> rowval = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));	
		List<WebElement> column6 = driver.findElements(By.xpath("//table[@id='file-records']/tbody/tr/td[2]"));
		for(WebElement col6 : column6) {
			List<WebElement> actionIcons = col6.findElements(By.tagName("button"));
			for(int i= 0; i<actionIcons.size(); i++) 
				verifyElement(actionIcons.get(i), "");	
		}
		Thread.sleep(3000);
	}

	/*		
		for(WebElement row: rowval) {
			List<WebElement> cells = row.findElements(By.tagName("td"));
			for(WebElement cell : cells) {
				List<WebElement> actionIcons = cell.findElements(By.tagName("button"));
				for(int i= 0; i<actionIcons.size(); i++) 
					verifyElement(actionIcons.get(i), "");		
			}
		}
	}
	 */
	//		for(int roww=1; roww<=rowval.size(); roww++) {
	//			List<WebElement> cell = rowval.get(roww).findElements(By.tagName("td"));
	////			System.out.println(cell.get(i));
	//			List<WebElement> actionIcons = breport.objects.RecordsObjects.getactionIcons.findElements(By.tagName("button"));
	//			System.out.println(roww);
	//			System.out.println(actionIcons.size());
	//			verifyElement(rowval.get(roww),"");
	//			for(int i= 0; i<actionIcons.size(); i++) 
	//				
	//			verifyElement(actionIcons.get(i), rowval.get(roww).getText());


	//		List<WebElement> rows = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));	

	//		List<WebElement> cell = rows.get(4).findElements(By.tagName("td"));
	//		System.out.println(cell.size());

	//		System.out.println(cell.get(0).getText());

	//		for(int i= 1; i<rows.size(); i++) {
	//			List<WebElement> cell1 = rows.get(i).findElements(By.tagName("td"));
	////			System.out.println(cell1.get(5));


	public static void transferToReport() throws InterruptedException {

		String pointer = breport.objects.RecordsObjects.transferToReport.getCssValue("cursor");
		String appType = breport.objects.NavigationObjects.applicationType_menu.getText();

		if(appType.equals("ALL")) {
			breport.objects.RecordsObjects.row_odd.click();
			click (breport.objects.RecordsObjects.transferToReport);
			Thread.sleep(5000);
			verifyElement(breport.objects.RecordsObjects.dialog_closeButton, "Close button is present");
			verifyElement(breport.objects.RecordsObjects.dialog_okButton, "OK button is present");
			Assert.assertEquals("Please select specific application type, its not working for 'ALL' application type", breport.objects.RecordsObjects.dialog_title.getText());

			click(breport.objects.RecordsObjects.dialog_okButton);	
			Thread.sleep(5000);

			click(breport.objects.NavigationObjects.applicationType_menu);
			List<WebElement> itemsInDropdown = breport.objects.NavigationObjects.applicationType_list.findElements(By.className("appTypeClass"));
			int size = itemsInDropdown.size();
			int randmNumber = ThreadLocalRandom.current().nextInt(0, size);
			itemsInDropdown.get(randmNumber).click();
			Thread.sleep(5000);
		}

		List<WebElement> rows = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));
		String firstRow = rows.get(1).getText();
		if(firstRow.equals("No data available in table")) {
			System.out.println("File records table is empty");
			selectMachine();
		}
		else if(pointer.equals("not-allowed")){
			rows.get(1).click();
			Thread.sleep(3000);
			System.out.println("Transfer to report button is enabled now");

			breport.objects.RecordsObjects.transferToReport.click();
		}
		else {
			System.out.println("Transfer to report button is already enabled");
			breport.objects.RecordsObjects.transferToReport.click();
		}

		verifyElement(breport.objects.RecordsObjects.dialog_closeButton, "Close button is present");
		verifyElement(breport.objects.RecordsObjects.dialog_okButton, "OK button is present");
		Thread.sleep(5000);
		Assert.assertEquals(breport.objects.RecordsObjects.dialog_title.getText(), "Added to Daily Report");
		click(breport.objects.RecordsObjects.dialog_okButton);		
	}

	public static void pagination() throws InterruptedException  {
		scrollDown();
		Thread.sleep(5000);
		List<WebElement> pagination = breport.objects.RecordsObjects.pagination.findElements(By.tagName("a"));
		List<WebElement> rows = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));	

		String xpath1 = "//ul[@class='pagination']//a[contains(text(),'";
		String xpath2 = "')]";
		int x=2;

		if(pagination.size()>3) {
			int i = 0;
			while (breport.objects.RecordsObjects.paginate_nextButton.getCssValue("cursor").equals("pointer")) {
				breport.objects.RecordsObjects.paginate_nextButton.click();

				String final_xpath = xpath1+x+xpath2;
				verifyColor(driver.findElement(By.xpath(final_xpath)), "background-color", "#004477");
				System.out.println("We are on page " +x);
				x++;
				Thread.sleep(500);
				Assert.assertEquals(10, rows.size()-1);

				i++;
			}
		}else {
			Assert.assertEquals(breport.objects.RecordsObjects.paginate_preButton.getCssValue("cursor"),"not-allowed");
			Assert.assertEquals(breport.objects.RecordsObjects.paginate_nextButton.getCssValue("cursor"),"not-allowed");

			System.out.println("Pagination does not exist");
		}
	}

	//		String[] s = new String[pagination.size()];
	//		for(WebElement p : pagination)
	//		{
	//			s[i] = p.getCssValue("cursor");
	//			if(s[i].equals("not-allowed"))
	//			{
	//				System.out.println("No element found");
	//			}
	//			else
	//			{
	//				p.click();
	//			}
	//		}

	public static void buttonGroup() {

		List<WebElement> buttons = breport.objects.RecordsObjects.buttons.findElements(By.tagName("a"));
		for(int k = 1; k<buttons.size(); k++) {
			verifyElement(buttons.get(k), "");
			System.out.println(buttons.get(k).getText());
		}
	}

	public static void fileRecordsLength() {

		int count = 0;
		String[] pages = {"10", "25", "50", "100"};
		Select record = new Select(breport.objects.RecordsObjects.filerecords_dropdown);

		List<WebElement> options = record.getOptions();
		for (WebElement rec : options) {
			for(int i = 0; i<pages.length; i++) {
				if (rec.getText().equals(pages[i])) {
					System.out.println(rec.getText() + " and " + pages[i] + " matched");
					count++;
				}
			}
		}
		if (count==pages.length) {
			System.out.println("Matched");
			Assert.assertTrue(true);
		}else {
			System.out.println("list doesn't match");
		}
	}

	//		List<WebElement> records = breport.objects.RecordsObjects.filerecords_dropdown.findElements(By.tagName("option"));
	//		System.out.println(records.size());
	//		System.out.println(records.get(0));
	//		String[] s = new String[records.size()];
	//		for(WebElement r : records) {
	//			r.getText();
	//		}
	//		ArrayList<Integer> page = new ArrayList<Integer>(Arrays.asList(10, 25, 50, 100));
	//		
	//		boolean isEqual = page.equals(records);
	//		System.out.println(isEqual);
	//	}

	public static void printSelected() throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(3000);
		click(breport.objects.NavigationObjects.applicationType_menu);
		click(driver.findElement(By.id("ALL")));
		Thread.sleep(3000);
		breport.objects.RecordsObjects.row_even.click();


		String pointer = breport.objects.RecordsObjects.printButton.getCssValue("cursor");
		if(pointer.equals("not-allowed")) {
			breport.objects.RecordsObjects.row_odd.click();
			click(breport.objects.RecordsObjects.printButton);
		}
		else {
			click(breport.objects.RecordsObjects.printButton);
		}

		Thread.sleep(3000);
		verifyTexts(breport.objects.RecordsObjects.print_title, "Print Preview settings", "Print settings title is present");
		verifyTexts(breport.objects.RecordsObjects.print_dropdownLable, "Select type of diagrams :", "Dropdown lable is present");
		verifyElement(breport.objects.RecordsObjects.print_dropdown, "");

		Select type = new Select (breport.objects.RecordsObjects.print_dropdown);
		List<WebElement> list = type.getOptions();
		int size = list.size();
		int random = ThreadLocalRandom.current().nextInt(0, size);
		list.get(random).click();

		click(breport.objects.RecordsObjects.print_button);
		Thread.sleep(5000);
		verifyTexts(breport.objects.RecordsObjects.dialog_title, "1 file(s) are successfully exported", "dialog title verified");
		verifyElement(breport.objects.RecordsObjects.dialog_closeButton, "Close button is present");
		verifyElement(breport.objects.RecordsObjects.dialog_okButton, "OK button is present");
		click(breport.objects.RecordsObjects.dialog_okButton);

		verifyTexts(breport.objects.RecordsObjects.printPreview_heading, "Print Preview", "Print preview header is present");
		verifyElement(breport.objects.RecordsObjects.printPreview_export, "Export option is present");
		verifyElement(breport.objects.RecordsObjects.printPage, "Print option is present");

		moveToElement(breport.objects.RecordsObjects.print_close);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		click(breport.objects.RecordsObjects.print_close);
		Thread.sleep(3000);
		click(breport.objects.NavigationObjects.record_menu);
	}

	public static void delete() throws InterruptedException {
		String pointer = breport.objects.RecordsObjects.deleteButton.getCssValue("cursor");
		if(pointer.equals("not-allowed")) {
			breport.objects.RecordsObjects.row_odd.click();
			click(breport.objects.RecordsObjects.deleteButton);
		}
		else {
			click(breport.objects.RecordsObjects.deleteButton);
		}
		Thread.sleep(2000);
		verifyTexts(breport.objects.RecordsObjects.dialog_title, "Are You sure?", "dialog title verified");
		verifyElement(breport.objects.RecordsObjects.dialog_closeButton, "Close button is present");
		verifyElement(breport.objects.RecordsObjects.dialog_okButton, "OK button is present");
		verifyElement(breport.objects.RecordsObjects.dialog_cancelButton, "Cancel button is present");
		click(breport.objects.RecordsObjects.dialog_cancelButton);
		Thread.sleep(2000);
	}

	public static void search(String search_keyword) throws InterruptedException {
		Thread.sleep(3000);
		//		String search_keyword = "Data";
		click(breport.objects.RecordsObjects.searchBox);
		sendKeys(breport.objects.RecordsObjects.searchBox, search_keyword);

		List<WebElement> rows = breport.objects.RecordsObjects.fileRecordsTable.findElements(By.tagName("tr"));

		int count = 1;
		for (int row= 1; row<rows.size(); row++) {
			String rowdata = rows.get(row).getText();
			System.out.println(rowdata);

			boolean result = StringUtils.containsIgnoreCase(rowdata, search_keyword);
			if(result == true) {
				System.out.println("Search result matched");
				count++;
			}else {
				System.out.println("not matched");
			}

		}if(count==rows.size()) {
			System.out.println("Final result matched");
			Assert.assertTrue(true);
		}else {
			System.out.println("Tes Failed");
			Assert.assertTrue(false);
		}


		/*
		int rowcount = 1;
			for(WebElement r : rows) {
				List<WebElement> cells = r.findElements(By.tagName("td"));
				for(WebElement cell : cells) {
				String rowdata = cell.getText();
				System.out.println(rowdata);
				if(rowdata.contains(search_keyword)) {
//					Assert.assertTrue(true);
					System.out.println("jkdjddkdkffk");
				}else {
//					Assert.assertTrue(false);
					System.out.println("not matched");
				}
				rowcount++;
				}
				List<WebElement> col1 = r.findElements(By.className("sorting_1"));
				for(WebElement col : col1) {
				System.out.println(col.getText());
			}
		}			
				List<WebElement> column1 = driver.findElements(By.xpath("//table[@id='file-records']/tbody/tr/td[1]"));
				System.out.println("Total number of rows "+column1.size());
				int row_num = 1;
				for(WebElement col1 : column1) {
				System.out.println(col1.getText());
				String filename = col1.getText();
				if(filename.contains(search_keyword)) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
				row_num++;
				}
		}
	}
		 */
	}				

	public static void mergeFile() throws InterruptedException {

		if (!breport.objects.NavigationObjects.applicationType_menu.getText().equals("CUT")) {
			click(breport.objects.NavigationObjects.applicationType_menu);
			click(driver.findElement(By.id("CUT")));
			Thread.sleep(10000);
		}

		String pointer = breport.objects.RecordsObjects.transferToReport.getCssValue("cursor");
		if(pointer.equals("not-allowed")) {
			click(breport.objects.RecordsObjects.row_odd);
			click(breport.objects.RecordsObjects.row_even);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			click(breport.objects.RecordsObjects.mergeButton);
		}else {
			click(breport.objects.RecordsObjects.mergeButton);
		}
		Thread.sleep(2000);
		verifyTexts(breport.objects.RecordsObjects.merge_dialoge_title, "File Merge Confirmation", "Title is present");
		verifyTexts(breport.objects.RecordsObjects.merge_dialoge_message, "Are you sure you wish to merge the selected files?", "Confimation message is present");
		verifyElement(breport.objects.RecordsObjects.mergeYes_button, "YES button is present");
		verifyElement(breport.objects.RecordsObjects.mergeNo_button, "NO button is present");
		click(breport.objects.RecordsObjects.mergeNo_button);	
		Thread.sleep(2000);
	}

	public static void exportToIFC() throws InterruptedException {

		if (!breport.objects.NavigationObjects.applicationType_menu.getText().equals("SOB")) {
			click(breport.objects.NavigationObjects.applicationType_menu);
			click(driver.findElement(By.id("SOB")));
		}
		click(breport.objects.RecordsObjects.row_odd);
		String pointer = breport.objects.RecordsObjects.transferToReport.getCssValue("cursor");
		if(pointer.equals("not-allowed")) {
			click(breport.objects.RecordsObjects.row_odd);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			click(breport.objects.RecordsObjects.exportToIFCButton);
		}else {
			click(breport.objects.RecordsObjects.exportToIFCButton);
		}
		Thread.sleep(2000);
		verifyTexts(breport.objects.RecordsObjects.export_dialoge_title, "Export to IFC confirmation", "Title is present");
		verifyTexts(breport.objects.RecordsObjects.export_dialoge_message, "Do you wish to export the selected files to IFC?", "Confirmation message is present");
		verifyElement(breport.objects.RecordsObjects.exportYes_button, "YES button is present");
		verifyElement(breport.objects.RecordsObjects.exportNo_button, "NO button is present");
		click(breport.objects.RecordsObjects.exportNo_button);	
		Thread.sleep(2000);

	}
}

















