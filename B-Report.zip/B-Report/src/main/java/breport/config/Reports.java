package breport.config;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Reports {
	
	public static String report_name = "Testreport"+".html";
	public static ExtentReports report;
	public static ExtentTest test;
	
	
	public static ExtentReports getReport(String reportPath) {
		if(report == null) {
//			ExtentHtmlReporter reporter = new ExtentHtmlReporter(reportPath + report_name);
			report = new ExtentReports(reportPath + report_name);
//			report.attachReporter(reporter);
			report.addSystemInfo("Browser", "Chrome");
			report.addSystemInfo("Selenium Version", "3.141.59");
			report.addSystemInfo("Author", "Sanjana");
//			report.loadConfig(configFile);
			
	}
		return report;
}
}
