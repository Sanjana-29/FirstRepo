package breport.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ReportsObjects {
	
	@FindBy (id = "collapseFilter")
	public static WebElement filter;
	
	@FindBy (id="pile-input")
	public static WebElement filter_pileno;
	
	@FindBy (id="reportrange")
	public static WebElement filter_daterange;
	
	@FindBy (id="resetFilter")
	public static WebElement filter_reset;
	
	@FindBy (xpath = "//div[contains(text(),'File List')]")
	public static WebElement filelist_title;
	
	@FindBy (id = "file_table_wrapper")
	public static WebElement fileTable;
	
	@FindBy (id = "file_table_info")
	public static WebElement fileTable_info;
	
	@FindBy (id = "file_table_paginate")
	public static WebElement fileTable_paginate;
	
	@FindBy (id = 
	
	
}
